### Template sandbox ###

The templates in this folder are being tested and may or may not work

### vmss-docker-simple.json ###

Deploy a simple Ubuntu/Docker scale set.

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fgbowerman%2Fazure-myriad%2Fmaster%2Ftesting%2Fvmss-docker-simple.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
<br/><br/>


### vmss-nsg-nic.json ###

Testing assigning a network security group to a scale set.

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fgbowerman%2Fazure-myriad%2Fmaster%2Ftesting%2Fvmss-nsg-nic.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
<br/><br/>

