### Simple VM Scale Set template ###

OS: Ubuntu 14.04, VM Size: Standard_DS1, Storage: Premium_LRS

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fgbowerman%2Fazure-myriad%2Fmaster%2Fdemo%2Fvmss-ubuntu-vnet-storage.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
<a href="http://armviz.io/#/?load=https%3A%2F%2Fraw.githubusercontent.com%2Fgbowerman%2Fazure-myriad%2Fmaster%2Fdemo%2Fvmss-ubuntu-vnet-storage.json" target="_blank">
    <img src="http://armviz.io/visualizebutton.png"/>
</a>

